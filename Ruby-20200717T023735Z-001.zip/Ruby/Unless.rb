puts "Como você se chama?"
nome = gets.chomp
unless nome.empty?
  puts "Olá #{nome}! Seja bem vindo, #{nome}"

end
gets
