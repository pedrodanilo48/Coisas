puts "Digite um número"
numero = gets.chomp.to_i
for i in 1..numero
  if i.even?
puts "A soma de pares de 1 até #{numero} é #{i+=i}"
end
end
gets
# Não houve qualquer questão explicando como executar código semelhante.
