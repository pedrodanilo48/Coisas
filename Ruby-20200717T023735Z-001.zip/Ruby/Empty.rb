puts "Como você se chama?"
nome = gets.chomp
if nome.empty?
  puts "Você não digitou o seu nome."
end
gets
