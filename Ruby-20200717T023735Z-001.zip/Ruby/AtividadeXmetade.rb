puts "Digite um número."
x = gets.chomp.to_i
puts "A metade de #{x} é #{x/2}"
