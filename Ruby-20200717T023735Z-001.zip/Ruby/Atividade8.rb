puts "Em kg, qual o seu peso?"
peso = gets.chomp.to_f
puts "Em metros, qual a sua altura?"
altura = gets.chomp.to_f
IMC = peso/altura**2
if IMC < 17
  puts "Muito abaixo do peso"
elsif IMC<18.5
  puts "Abaixo do peso"
elsif IMC<25
  puts "Peso normal"
elsif IMC<30
  puts "Um pouco acima do peso"
elsif IMC<35
  puts "Obeso"
else
  puts "Obesidade severa"
end

gets
