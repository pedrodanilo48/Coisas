for i in 1..10
  puts "O valor de i é #{i}"
if i==3
  redo
end
end
gets
