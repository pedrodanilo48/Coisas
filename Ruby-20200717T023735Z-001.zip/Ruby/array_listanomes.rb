listaa = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
puts "Qual o 1° nome?"
listaa[0] <<
puts "Qual o 2° nome?"
listaa[1] <<
puts "Qual o 3° nome?"
listaa[2] <<
puts "Qual o 4° nome?"
listaa[3] <<
puts "Qual o 5° nome?"
listaa[4] <<
puts "Qual o 6° nome?"
listaa[5] <<
puts "Qual o 7° nome?"
listaa[6] <<
puts "Qual o 8° nome?"
listaa[7] <<
puts "Qual o 9° nome?"
listaa[8] <<
puts "Qual o 9° nome?"
listaa[9] <<
puts listaa [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
gets
