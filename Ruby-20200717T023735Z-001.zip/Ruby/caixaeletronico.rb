loop do
puts "Quanto deseja retirar?"
quantidade = gets.chomp.to_i
break if quantidade == 0
numeroprimo5 = quantidade%5 ==0
numeroprimo2 = quantidade%2 ==0
quantidadearetirar = quantidade
if numeroprimo5 or numeroprimo2
  cedulascem = quantidade/100
  quantidade = quantidade-(cedulascem * 100)
  cedulascinquenta = quantidade/50
  quantidade = quantidade-(cedulascinquenta * 50)
  cedulasvinte = quantidade / 20
  quantidade = quantidade-(cedulasvinte * 20)
  cedulasdez = quantidade / 10
  quantidade = quantidade-(cedulasdez * 10)
  cedulascinco = quantidade / 5
  quantidade = quantidade-(cedulascinco * 5)
  cedulasdois = quantidade / 2
  quantidade = quantidade-(cedulasdois * 2)
  puts "Valor total a ser retirado = #{quantidadearetirar} reais"
  puts "Cédulas de cem reais = #{cedulascem} reais"
  puts "Cédulas de cinquenta reais = #{cedulascinquenta} reais"
  puts "Cédulas de vinte reais = #{cedulasvinte} reais"
  puts "Cédulas de dez reais = #{cedulasdez} reais"
  puts "Cédulas de cinco reais = #{cedulascinco} reais"
  puts "Cédulas de dois reais = #{cedulasdois} reais"
else
  puts "O valor solicitado deve ser múltiplo de R$ 2, R$ 5, R$ 10, R$ 20, R$ 50 ou R$ 100 reais!"
end
end
gets
