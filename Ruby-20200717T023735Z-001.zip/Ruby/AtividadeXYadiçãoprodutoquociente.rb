puts "Digite um número."
x = gets.chomp.to_f
puts "Digite outro valor."
y = gets.chomp.to_f
puts "O resultado da soma de #{x} e #{y} é #{x + y}"
puts "O resultado do produto de #{x} e #{y} é #{x * y}"
puts "O resultado do quociente da razão entre #{x} e #{y} é #{x % y}"
