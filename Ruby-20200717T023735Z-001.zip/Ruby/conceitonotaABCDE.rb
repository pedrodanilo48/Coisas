puts "Quer saber o conceito de sua nota? Digite-a."
nota = gets.chomp.to_i
if nota>=80
  puts "Seu conceito é A!"
elsif nota>=60
  puts "Seu conceito é B!"
elsif nota>=40
  puts "Seu conceito é C!"
elsif nota>=20
  puts "Seu conceito é D!"
else nota>=0
  puts "Seu conceito é E!"
end
gets
