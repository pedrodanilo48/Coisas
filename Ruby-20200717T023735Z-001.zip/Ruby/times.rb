puts "Digite um número."
numero = gets.chomp.to_i
11.times {  |i|
 puts "O número #{numero} vezes #{i} é igual à: #{numero*i}"
}
gets
