puts "Digite um número."
x = gets.chomp.to_i
puts "Digite outro valor."
y = gets.chomp.to_i
puts "O resultado de #{x} elevado à #{y} é #{x**y}"
