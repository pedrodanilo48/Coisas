puts "Digite um número e saiba qual o mês do ano e quantos dias ele tem!"
mes = gets.chomp.to_i
case mes
when 1
  puts "O mês é janeiro e tem 31 dias!"
when 2
  puts "O mês é fevereiro e tem 29 dias!"
when 3
  puts "O mês é março e tem 31 dias!"
when 4
  puts "O mês é abril e tem 30 dias!"
when 5
  puts "O mês é maio e tem 31 dias!"
when 6
  puts "O mês é junho e tem 30 dias!"
when 7
  puts "O mês é julho e tem 31 dias!"
when 8
  puts "O mês é agosto e tem 31 dias!"
when 9
  puts "O mês é setembro e tem 30 dias!"
when 10
  puts "O mês é outubro e tem 31 dias!"
when 11
  puts "O mês é novembro e tem 30 dias!"
when 12
  puts "O mês é dezembro e tem 31 dias!"
else
  puts "Apenas números de 1 à 12!"
end
gets
