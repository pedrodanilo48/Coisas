puts "Digite um número inteiro"
x = gets.chomp.to_i
puts "Digite outro número inteiro"
y = gets.chomp.to_i
for i in 1..y
unless i>y
  puts "O #{x} elevado a #{y} é igual a #{x*i}"
end
end
gets
