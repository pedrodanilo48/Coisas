puts "Valor"
valor = gets.chomp.to_i
(1..n).each do  |i|
  if i.even?
  puts "A soma dos números pares de 1 à #{valor} é igual a #{i+}"
end
end
gets
