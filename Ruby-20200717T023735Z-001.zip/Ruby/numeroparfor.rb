puts "Digite um número e saiba quantos pares há até ele!"
numero = gets.chomp.to_i
for i in 1..numero
  if i%2==0
    puts "Os valores são #{i}"
end
end
gets
