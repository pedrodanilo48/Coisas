puts "Digite um número e saiba quais são divisíveis por 3 ou 5!"
numero = gets.chomp.to_i
(1..numero).each do |i|
if i%3==0
  puts "Os números divisíveis por 3 são:#{i} "
elsif i%5==0
  puts "Os números divisíveis por 5 são:#{i}"
end
end
gets
