puts "Digite um número e saiba a tabuada dele até 10!"
x = gets.chomp.to_i
(1..10).each do |i|
  puts "O #{x} vezes #{i} é #{x*i}"
end
gets
