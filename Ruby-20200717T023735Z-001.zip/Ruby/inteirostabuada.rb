puts "Digite um número inteiro e saiba a multiplicação dele de 1 à 10!"
numero = gets.chomp.to_i
puts "#{numero} vezes 1 é igual à #{numero*1}"
puts "#{numero} vezes 2 é igual à #{numero*2}"
puts "#{numero} vezes 3 é igual à #{numero*3}"
puts "#{numero} vezes 4 é igual à #{numero*4}"
puts "#{numero} vezes 5 é igual à #{numero*5}"
puts "#{numero} vezes 6 é igual à #{numero*6}"
puts "#{numero} vezes 7 é igual à #{numero*7}"
puts "#{numero} vezes 8 é igual à #{numero*8}"
puts "#{numero} vezes 9 é igual à #{numero*9}"
puts "#{numero} vezes 10 é igual à #{numero*10}"
gets
