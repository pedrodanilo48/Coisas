puts "Digite um número inteiro e saiba a multiplicação dele de 1 à 10!"
numero = gets.chomp.to_i
for algumnumero in 1..10
  puts "O número #{numero} vezes #{algumnumero} é igual a #{numero*algumnumero}"
end
gets
