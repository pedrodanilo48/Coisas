puts "Quer saber o conceito de sua nota? Digite-a."
nota = gets.chomp.to_i
case nota
when 80..100
  puts "Seu conceito é A!"
when 60..79
  puts "Seu conceito é B!"
when 40..59
  puts "Seu conceito é C!"
when 20..39
  puts "Seu conceito é D!"
when 0..19
  puts "Seu conceito é E!"
else "Apenas números de 0 à 100!"
end
gets
