for i in 1..10
  if i==7
    break
end
puts "O valor de i é #{i}"
end
gets
