for i in 1..10
  if i == 7
    next
end
puts "O valor de i é #{i}"
end
gets
