puts "Como você se chama?"
nome = gets.chomp
puts "Olá #{nome}! Seja bem vindo, #{nome}!" unless nome.empty?
gets
