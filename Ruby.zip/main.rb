finalizar = 1
while finalizar == 1
puts "Quanto você deseja sacar?"
sacar = gets.chomp.to_i
if (sacar%2==0 || sacar%5==0)
    cem=sacar/100
    sacar=sacar-(cem*100)
    cinquenta=sacar/50
    sacar=sacar-(cinquenta*50)
    vinte=sacar/20
    sacar=sacar-(vinte*20)
    dez=sacar/10
    sacar=sacar-(dez*10)
    cinco=sacar/5
    sacar=sacar-(cinco*5)
    dois=sacar/2
    sacar=sacar-(dois*2)
    puts "Você receberá #{cem} notas de cem, #{cinquenta} notas de cinquenta, #{vinte} notas de vinte, #{dez} notas de dez, #{cinco} notas de cinco e #{dois} notas de dois. Deseja sacar mais algum valor? sim/não = 1/0"
    finalizar = gets.chomp.to_i
else 
    puts "O valor solicitado deve ser múltiplo de R$ 2, R$ 5, R$ 10, R$ 20, R$ 50 ou R$ 100 reais!"
end
end